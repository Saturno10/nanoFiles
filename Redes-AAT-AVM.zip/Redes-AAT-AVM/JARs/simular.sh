#!/bin/bash

# Ejecutar java -jar directory.jar en un terminal
gnome-terminal -- java -jar Directory.jar &


# Ejecutar java -jar nanoFilesP2Palumnos.jar nf-shared1 en otro terminal
gnome-terminal -- java -jar nanoFilesP2Palumnos.jar nf-shared1 &


# Ejecutar java -jar nanoFilesP2Palumnos.jar nf-shared2 en otro terminal
gnome-terminal -- java -jar nanoFilesP2Palumnos.jar nf-shared2 &


# Ejecutar java -jar nanoFilesP2Palumnos.jar nf-shared13 en otro terminal
gnome-terminal -- java -jar nanoFilesP2Palumnos.jar nf-shared3 &

